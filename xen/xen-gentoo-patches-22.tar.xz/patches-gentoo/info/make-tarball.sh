#!/bin/bash

. /etc/init.d/functions.sh

DIR="$(pwd)"

PVER="$1"
SOURCDIR=${2:-"${DIR}"}

PATCHDIR="tmp/patches-gentoo"
INFODIR="${PATCHDIR}/info"

ARCHIVE="xen-gentoo-patches-${PVER}.tar.xz"

if [[ $# -lt 1 ]]; then
	einfo "Usage: $0 <patch ver> [patches source dir - default to current dir]"
	exit 1
fi

if [[ -e ${ARCHIVE} ]]; then
	eerror "Archive '${ARCHIVE}' does already exist! Abort."
	exit 1
fi

rm -rf ${ARCHIVE} tmp

mkdir -p ${INFODIR}

if [ -d ${SOURCDIR} ];then
	cp -rf ${SOURCDIR}/*.patch ${PATCHDIR} || exit 1
else
	cp -rf *.patch ${PATCHDIR} || exit 1
fi

if [[ -e README.Gentoo.patches ]]; then
	cp README.Gentoo.patches ${INFODIR}/ || exit 1
fi

cat >${INFODIR}/README <<-EOF
	Patchset generated on $(date).

	This patchset is collected by Gentoo's xen team .
EOF

cp $0 ${INFODIR}/ || exit 1

tar -cJf ${ARCHIVE} -C tmp . || exit 1
rm -rf tmp

einfo "Patchset generation run successfully :)"
einfo "File size of ${ARCHIVE}: $(du -bh ${ARCHIVE} | cut -f1)"
