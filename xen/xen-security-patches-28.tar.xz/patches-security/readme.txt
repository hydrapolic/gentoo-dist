
XSA-191,192,193,194,195,196: [X]
	EMBARGOED UNTIL 2016-11-22 12:00 UTC
	Gentoo-Bug:

XSA-197: [X]
	EMBARGOED UNTIL 2016-11-22 12:00 UTC
	Gentoo-Bug: 

XSA-202,203: [X]
	EMBARGOED UNTIL 2016-12-21 12:00 UTC
	Gentoo-Bug: 

XSA-207: [X]
	EMBARGOED UNTIL 2017-02-15 12:00 UTC
	Gentoo-Bug: 

[X] patches need apply to app-emulation/xen
[Y] patches need apply to app-emulation/xen-tools


